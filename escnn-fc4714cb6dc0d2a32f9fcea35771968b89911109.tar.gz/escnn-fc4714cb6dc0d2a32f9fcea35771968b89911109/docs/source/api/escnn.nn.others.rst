
Other modules
=============


MaxPoolChannels
~~~~~~~~~~~~~~~

.. autoclass:: escnn.nn.MaxPoolChannels
   :members:
   :show-inheritance:

