# Team

## Core Contributors

These people contributed directly to the codebase and helped build it.

- [Ajay Mandlekar](https://ai.stanford.edu/~amandlek/)
- [Danfei Xu](https://faculty.cc.gatech.edu/~danfei/)
- [Josiah Wong](https://www.jowo.me/about)
- [Soroush Nasiriany](http://snasiriany.me/)
- [Chen Wang](http://www.chenwangjeremy.net/)
- [Matthew Bronars](https://bronars.github.io/)

## Mentors

These people have guided the development of the framework.

- [Roberto Martin-Martin](https://robertomartinmartin.com/)
- [Yuke Zhu](https://www.cs.utexas.edu/~yukez/)
- [Silvio Savarese](https://www.linkedin.com/in/silvio-savarese-97b76114/)
- [Fei-Fei Li](https://profiles.stanford.edu/fei-fei-li)

